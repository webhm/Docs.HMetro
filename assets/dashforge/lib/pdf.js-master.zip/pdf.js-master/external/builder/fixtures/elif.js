'use strict';
//#elif TRUE
var a;
//#endif
